<!--Start breadcrumb area-->
<section class="breadcrumb-area style2" style="background-image: url(<?=base_url('front-assets/images/resources/breadcrumb-bg-2.jpg')?>);">
    <div class="container">
        <div class="row">
            <div class="col-xl-12">
                <div class="inner-content-box clearfix">
                    <div class="title-s2 text-center">
                        <h1>Gift Codes</h1>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!--End breadcrumb area-->
<div class="container mt-5">
    <div class="row">
        <div class="col-md-4">
            <?=$this->load->view('frontpages/leftnav')?>
        </div>
        <div class="col-md-8">
            <div class="row mt-5">
                <div class="col-md-12">
                    <h4 class="text-center">No Gift Codes Found</h4>
                </div>
            </div>
        </div>
    </div>
</div>